import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-tirelire',
  templateUrl: './tirelire.component.html',
  styleUrls: ['./tirelire.component.css'],
})
export class TirelireComponent {
  @Input() numero: number = 0;
  @Input() valeur: number = 0;
  @Output() depense = new EventEmitter<number>();

  depenser() {
    this.depense.emit(this.valeur);
  }
}
