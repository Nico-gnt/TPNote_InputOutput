import { Component } from '@angular/core';

@Component({
  selector: 'app-box',
  templateUrl: './box.component.html',
  styleUrls: ['./box.component.css'],
})
export class BoxComponent {
  tirelire1 = 0;
  tirelire2 = 0;
  tirelire3 = 0;

  ajouter100Fr() {
    const tirelireAleatoire = Math.floor(Math.random() * 3) + 1; // tirelire aléatoire entre 1 et 3
    if (tirelireAleatoire === 1) {
      this.tirelire1 += 100;
    } else if (tirelireAleatoire === 2) {
      this.tirelire2 += 100;
    } else if (tirelireAleatoire === 3) {
      this.tirelire3 += 100;
    }
  }

  onDepense(valeur: number, numero: number) {
    if (numero === 1) {
      this.tirelire1 -= valeur;
    } else if (numero === 2) {
      this.tirelire2 -= valeur;
    } else if (numero === 3) {
      this.tirelire3 -= valeur;
    }
  }
}
